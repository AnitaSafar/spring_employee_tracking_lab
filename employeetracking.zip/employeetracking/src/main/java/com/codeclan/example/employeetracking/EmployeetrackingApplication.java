package com.codeclan.example.employeetracking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeetrackingApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeetrackingApplication.class, args);
	}

}
